# Soundboard
### Soundboard is a universal soundboard in Qt for linux using pulseaudio modules

# Features

- Simple UI
- Tabs to organize your sounds
- Automatically add a folder as tab
- Global hotkeys
- Saves configuration automatically
- Uses PulseAudio modules so it should work on almost any distribution
- Output to any recording stream
- Supports most common audio formats (mp3, wav, ogg)
- more to come...

# Screenshots
to be added...